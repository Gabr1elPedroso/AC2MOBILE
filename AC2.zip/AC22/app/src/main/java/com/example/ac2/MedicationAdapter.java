package com.example.ac2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MedicationAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Medication> medications;

    public MedicationAdapter(Context context, ArrayList<Medication> medications) {
        this.context = context;
        this.medications = medications;
    }

    @Override
    public int getCount() {
        return medications.size();
    }

    @Override
    public Object getItem(int position) {
        return medications.get(position);
    }

    @Override
    public long getItemId(int position) {
        return medications.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_medicamento, parent, false);
        }

        TextView textNome = convertView.findViewById(R.id.text_nome);
        TextView textDesc = convertView.findViewById(R.id.text_descricao);
        Button btnTomar = convertView.findViewById(R.id.btn_tomar);

        Medication med = medications.get(position);

        textNome.setText(med.getName() + " - " + med.getTime());
        textDesc.setText(med.getDescription());

        if (med.isTaken()) {
            btnTomar.setEnabled(false);
            btnTomar.setText("Já tomado");
        } else {
            btnTomar.setEnabled(true);
            btnTomar.setText("Marcar como tomado");
        }

        btnTomar.setOnClickListener(v -> {
            med.setTaken(true);
            MedicationDBHelper db = new MedicationDBHelper(context);
            db.updateMedication(med);
            notifyDataSetChanged();
        });

        return convertView;
    }
}

