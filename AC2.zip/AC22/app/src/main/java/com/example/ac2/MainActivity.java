package com.example.ac2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MedicationDBHelper dbHelper;
    private ListView listView;
    private MedicationAdapter adapter;
    private ArrayList<Medication> medications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new MedicationDBHelper(this);
        listView = findViewById(R.id.med_list);
        medications = dbHelper.getAllMedications();
        adapter = new MedicationAdapter(this, medications);
        listView.setAdapter(adapter);

        findViewById(R.id.btn_add).setOnClickListener(v -> {
            startActivity(new Intent(this, AddEditActivity.class));
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Medication med = medications.get(position);
            Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
            intent.putExtra("id", med.getId());
            intent.putExtra("name", med.getName());
            intent.putExtra("description", med.getDescription());
            intent.putExtra("time", med.getTime());
            startActivity(intent);
        });





        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            Medication med = medications.get(position);
            dbHelper.deleteMedication(med.getId());
            medications.remove(position);
            adapter.notifyDataSetChanged();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        medications.clear();
        medications.addAll(dbHelper.getAllMedications());
        adapter.notifyDataSetChanged();
    }
}