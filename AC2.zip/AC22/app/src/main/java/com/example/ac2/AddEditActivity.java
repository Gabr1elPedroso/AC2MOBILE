package com.example.ac2;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddEditActivity extends AppCompatActivity {

    private EditText nameField, descriptionField, timeField;
    private MedicationDBHelper dbHelper;
    
    private int medId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        nameField = findViewById(R.id.edit_name);
        descriptionField = findViewById(R.id.edit_description);
        timeField = findViewById(R.id.edit_time);
        dbHelper = new MedicationDBHelper(this);

        Intent intent = getIntent();
        if (intent.hasExtra("id")) {
            medId = intent.getIntExtra("id", -1);
            nameField.setText(intent.getStringExtra("name"));
            descriptionField.setText(intent.getStringExtra("description"));
            timeField.setText(intent.getStringExtra("time"));
        }

        findViewById(R.id.btn_save).setOnClickListener(v -> {
            String name = nameField.getText().toString();
            String description = descriptionField.getText().toString();
            String time = timeField.getText().toString();

            if (!name.isEmpty() && !time.isEmpty()) {
                if (medId == -1) {
                    dbHelper.insertMedication(name, description, time);
                } else {
                    Medication med = new Medication(medId, name, description, time, false);
                    dbHelper.updateMedication(med);
                }
                finish();
            } else {
                Toast.makeText(this, "Preencha nome e horário", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void setAlarm(String medName, String time) {
        String[] parts = time.split(":");
        if (parts.length != 2) return;

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(parts[0]));
        calendar.set(Calendar.MINUTE, Integer.parseInt(parts[1]));
        calendar.set(Calendar.SECOND, 0);

        if (calendar.before(Calendar.getInstance())) {
            calendar.add(Calendar.DAY_OF_MONTH, 1); // agenda para o próximo dia se já passou
        }

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("med_name", medName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, medName.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }

}


