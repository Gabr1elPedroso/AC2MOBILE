package com.example.ac2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class MedicationDBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "medications.db";
    private static final int DB_VERSION = 1;

    public MedicationDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE medication (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "description TEXT," +
                "time TEXT," +
                "taken INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS medication");
        onCreate(db);
    }

    public void insertMedication(String name, String description, String time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("description", description);
        values.put("time", time);
        values.put("taken", 0);
        db.insert("medication", null, values);
    }

    public ArrayList<Medication> getAllMedications() {
        ArrayList<Medication> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM medication", null);
        while (cursor.moveToNext()) {
            list.add(new Medication(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getInt(4) == 1
            ));
        }
        cursor.close();
        return list;
    }

    public void updateMedication(Medication med) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", med.getName());
        values.put("description", med.getDescription());
        values.put("time", med.getTime());
        values.put("taken", med.isTaken() ? 1 : 0);
        db.update("medication", values, "id=?", new String[]{String.valueOf(med.getId())});
    }

    public void deleteMedication(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("medication", "id=?", new String[]{String.valueOf(id)});
    }

    public void markAsTaken(int id) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("taken", 1);
        db.update("medication", values, "id=?", new String[]{String.valueOf(id)});
    }
}