package com.example.ac2;

public class Medication {
    private int id;
    private String name;
    private String description;
    private String time;
    private boolean taken;

    public Medication(int id, String name, String description, String time, boolean taken) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.time = time;
        this.taken = taken;
    }

    // Getters e setters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getTime() { return time; }
    public boolean isTaken() { return taken; }

    public void setTaken(boolean taken) { this.taken = taken; }
}